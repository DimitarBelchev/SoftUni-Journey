1.Отворете терминал в папката
2.Напишете npm i || npm install
3.Напиеште npm run start || node index
